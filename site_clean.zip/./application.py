# application.py
from mcp_api import create_app
app = create_app()